//: Playground - noun: a place where people can play

import Cocoa

var elems = 1...100

for rec in elems {
    
    switch rec {
    case 30...40:
        print("Viva Swift")
    default:
        if (rec % 5) == 0 {
            print("\(rec)\t\"Bingo")
        } else if rec % 2 == 0 {
            print("\(rec)\t\"Par")
        } else if rec % 2 == 1 {
            print("\(rec)\t\"Impar")
        }
    }
}
